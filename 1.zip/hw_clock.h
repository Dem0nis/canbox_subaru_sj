#ifndef HW_CLOCK_H
#define HW_CLOCK_H

void hw_clock_setup(void);

#endif

